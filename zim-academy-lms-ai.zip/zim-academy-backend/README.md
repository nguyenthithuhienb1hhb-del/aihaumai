# ZIM Academy - Module Quản lý Lớp học & AI

Backend Node.js + Express + MongoDB cho 5 nghiệp vụ trong đề bài, có áp dụng các lưu ý
trong ảnh "Zim academy review".

## Cài đặt

```bash
npm install
cp .env.example .env   # rồi điền MONGO_URI, JWT_SECRET, OPENAI_API_KEY...
npm run dev
```

## Cấu trúc & nghiệp vụ tương ứng

| File | Nghiệp vụ |
|---|---|
| `middleware/upload.js` + `routes/materialRoutes.js` (`POST /api/materials/lectures`, `/assignments`) | 1. Multer upload bài giảng/bài tập PDF/Word/Ảnh |
| `services/aiService.js` + `routes/aiRoutes.js` (`POST /api/ai/hint`) | 2. Gọi OpenAI/Gemini trả gợi ý, không giải hộ |
| `models/QuizSession.js` + `routes/quizRoutes.js` (`/start`, `/out`, `/submit`) | 1(quiz). Chống thoát bài, out > 3 lần = huỷ |
| `models/Resource.js` + `routes/resourceRoutes.js` (`GET /api/resources/recommend/:submissionId`) | 4. Gợi ý tài nguyên theo điểm yếu nhất |
| `services/voucherService.js` + `routes/enrollmentRoutes.js` (`PATCH /api/enrollment/:id/progress`) | 5. Tự động cấp voucher khi hoàn thành 100% |

## Đối chiếu với "Zim academy review" (ảnh 2, 3)

1. **UI/UX** — module này chỉ là backend/API, phần giao diện FE nên tham khảo repo
   `ui-ux-pro-max` được nhắc trong ảnh để làm UI "ít AI, giống người" và tự test kỹ trên
   desktop/mobile trước khi giao.
2. **Phân quyền** — xử lý bằng `middleware/auth.js` (`verifyToken` + `authorize(...roles)`).
   Không tách domain/dự án riêng, chỉ 1 backend + role `admin/teacher/student`, đúng như
   ghi chú "không cần tách ra nhiều dự án hay Domain khác nhau, chỉ cần phân quyền là được".
3. **Logic cụ thể** — mỗi flow (upload, AI hint, quiz, resource, voucher) được tách route
   riêng, dễ giao từng phần cho AI code tiếp mà không bị loãng. Có dùng MongoDB để lưu dữ
   liệu như ghi chú yêu cầu "cần có database để lưu trữ dữ liệu".
4. **Model AI khi code tiếp** — phần logic phức tạp (vd: hoàn thiện `quizRoutes.js`, thêm
   chấm điểm tự động) nên dùng Claude Opus + effort cao như ghi chú gợi ý.
5. **Trang điểm web** — chưa áp dụng (thuộc phần FE, làm sau khi nghiệp vụ chạy đúng).
6. **Đặt mình vào vị trí người dùng** — API trả message lỗi rõ ràng bằng tiếng Việt cho
   FE hiển thị; quiz tự huỷ có kèm lý do (`cancelledReason`) để hiển thị cho học viên.
7. **Dùng tiếng Anh trong prompt** — `SYSTEM_PROMPT` trong `services/aiService.js` được
   viết bằng tiếng Anh để AI hiểu tốt hơn và tiết kiệm token.

## Việc cần làm tiếp (ngoài phạm vi code này)

- Route đăng nhập/đăng ký (`/api/auth`) để cấp JWT — hiện middleware giả định token đã có.
- Tích hợp S3 cho upload video (ghi chú #3 lưu ý free tier S3 hết nhanh với video, nên demo
  bằng ảnh trước, video để sau).
- Cron job/hook chấm điểm tự động để điền `scoresBySkill` cho `Submission` (hiện phải nhập
  tay hoặc từ module chấm bài khác).
